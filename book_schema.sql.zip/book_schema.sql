-- book schema
DROP TABLE BOOK CASCADE CONSTRAINTS;
DROP TABLE USERTABLE CASCADE CONSTRAINTS;
DROP TABLE REVIEW CASCADE CONSTRAINTS;
DROP TABLE READINGLIST CASCADE CONSTRAINTS;
DROP SEQUENCE seqBook;
DROP SEQUENCE seqUser;
DROP SEQUENCE seqReview;
DROP SEQUENCE seqReadingL;

CREATE TABLE BOOK(
      ISBN              VarChar(15)       NOT NULL,
      Title             Char(50)          NOT NULL,
      Author            VarChar(50)       NOT NULL,
      Genre             Char(20)          NOT NULL,
      CONSTRAINT        BOOK_PK           PRIMARY KEY(ISBN)
      );

CREATE SEQUENCE seqBook INCREMENT BY 1 START WITH 1;

CREATE TABLE USERTABLE (
      UserID                VarChar(25)         NOT NULL,
      Username              VarChar(50)         NOT NULL,
      FirstName             Char(50)            NOT NULL,
      LastName                Char(25)          NOT NULL,
      CONSTRAINT              USERPK      PRIMARY KEY(UserID)
      );

CREATE SEQUENCE seqUser INCREMENT BY 1 START WITH 1;

CREATE TABLE REVIEW (
    ReviewID   Int          NOT NULL,
    UserID     VarChar(25)  NOT NULL,
    BookISBN   VarChar(15)  NOT NULL,
    Rating     VarChar(15),
    Note       Char(50),    
    Title      Char(50)     NOT NULL,
    CONSTRAINT REVIEW_FK FOREIGN KEY(BookISBN) REFERENCES BOOK(ISBN),
    CONSTRAINT REVIEW_PK PRIMARY KEY(ReviewID),
    CONSTRAINT REVIEW_FK_USER FOREIGN KEY(UserID) REFERENCES USERTABLE(UserId)
);


CREATE SEQUENCE seqReview INCREMENT BY 1 START WITH 1;

CREATE TABLE READINGLIST (
    Title       Char(100)       NOT NULL,
    DateAdded   VarChar(20)     NOT NULL,
    ReadingLID  Int,
    Status      VarChar(20)     NOT NULL, 
    UserID      VarChar(25)     NOT NULL,
    CONSTRAINT READING_L_PK     PRIMARY KEY(ReadingLID),
    CONSTRAINT READING_LIST_FK  FOREIGN KEY(UserID) REFERENCES USERTABLE(UserID)
);

   
CREATE SEQUENCE seqReadingL INCREMENT BY 1 START WITH 1;