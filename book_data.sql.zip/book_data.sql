-- Book Data for Abby Donoghue and Reade Hauge

-- Modify data for the BOOK table
INSERT INTO BOOK (ISBN, Title, Author, Genre) VALUES ('9781501161933',
'The Seven Husbands of Evelyn Hugo', 'Taylor Jenkins Reid', 'Fiction');
INSERT INTO BOOK (ISBN, Title, Author, Genre) VALUES ('9781649374042', 
'Fourth Wing', 'Author B', 'Mystery');
INSERT INTO BOOK (ISBN, Title, Author, Genre) VALUES ('9780062060617', 
'Song of Achilles', 'Madeline Miller', 'Historical Fiction');
INSERT INTO BOOK (ISBN, Title, Author, Genre) VALUES ('9780439023528', 
'The Hunger Games', 'Suzanne Collins', 'Science Fiction');
INSERT INTO BOOK (ISBN, Title, Author, Genre) VALUES ('9780525478812', 
'The Fault In Our Stars', 'John Green', 'Romance');
INSERT INTO BOOK (ISBN, Title, Author, Genre) VALUES ('9780316015844', 
'Twilight', 'Stephenie Meyer', 'Fantasy');
INSERT INTO BOOK (ISBN, Title, Author, Genre) VALUES ('9780375831003', 
'The Book Thief', 'Markus Zusak', 'Historical Fiction');
INSERT INTO BOOK (ISBN, Title, Author, Genre) VALUES ('9781619635180', 
'A Court Of Thorns And Roses', 'Sarah J. Maas', 'Fantasy');
INSERT INTO BOOK (ISBN, Title, Author, Genre) VALUES ('9780590353427', 
'Harry Potter', 'J.K. Rowling', 'Fantasy');
INSERT INTO BOOK (ISBN, Title, Author, Genre) VALUES ('9781423103349', 
'Percy Jackson', 'Rick Riordan', 'Fantasy');
INSERT INTO BOOK (ISBN, Title, Author, Genre) VALUES ('9780735219090',
'Where the Crawdads Sing', 'Delia Owens', 'Mystery');
INSERT INTO BOOK (ISBN, Title, Author, Genre) VALUES ('9781982137335',
'Educated: A Memoir', 'Tara Westover', 'Memoir');
INSERT INTO BOOK (ISBN, Title, Author, Genre) VALUES ('9780525562044', 
'Becoming', 'Michelle Obama', 'Biography');
INSERT INTO BOOK (ISBN, Title, Author, Genre) VALUES ('9781984806758', 
'The Silent Patient', 'Alex Michaelides', 'Thriller');
INSERT INTO BOOK (ISBN, Title, Author, Genre) VALUES ('9780062871291', 
'Daisy Jones and The Six', 'Taylor Jenkins Reid', 'Historical Fiction');
INSERT INTO BOOK (ISBN, Title, Author, Genre) VALUES ('9781250787299', 
'Project Hail Mary', 'Andy Weir', 'Science Fiction');
INSERT INTO BOOK (ISBN, Title, Author, Genre) VALUES ('9781984818355', 
'The Vanishing Half', 'Brit Bennett', 'Fiction');
INSERT INTO BOOK (ISBN, Title, Author, Genre) VALUES ('9781250779171', 
'Malibu Rising', 'Taylor Jenkins Reid', 'Historical Fiction');
INSERT INTO BOOK (ISBN, Title, Author, Genre) VALUES ('9780593135204', 
'The Invisible Life of Addie LaRue', 'V.E. Schwab', 'Fantasy');
INSERT INTO BOOK (ISBN, Title, Author, Genre) VALUES ('9780316382716', 
'Circe', 'Madeline Miller', 'Fantasy');


-- Modify data for the USERTABLE table
INSERT INTO USERTABLE (UserID, Username, FirstName, LastName) VALUES ('user1', 
'Abby_Donoghue', 'Abby', 'Donoghue');
INSERT INTO USERTABLE (UserID, Username, FirstName, LastName) VALUES ('user2', 
'Reade_Hauge', 'Reade', 'Hauge');
INSERT INTO USERTABLE (UserID, Username, FirstName, LastName) VALUES ('user3', 
'Ebelechukwu_Nwafor', 'Ebelechukwu', 'Nwafor');

-- Modify data for the REVIEW table
INSERT INTO REVIEW (ReviewID, UserID, BookISBN, Rating, Note, Title) VALUES (1, 
'user1', '9781501161933', 4.5, 'Great book!', 'The Seven Husbands of Evelyn Hugo');
INSERT INTO REVIEW (ReviewID, UserID, BookISBN, Rating, Note, Title) VALUES (2, 
'user2', '9781649374042', 3.0, 'Interesting read.', 'Fourth Wing');
INSERT INTO REVIEW (ReviewID, UserID, BookISBN, Rating, Note, Title) VALUES (3, 
'user3', '9780062060617', 5.0, 'Amazing!', 'Song of Achilles');
INSERT INTO REVIEW (ReviewID, USerID, BookISBN, Rating, Note, Title) VALUES (4, 
'user1', '9780439023528', 4.2, 'Epic!', 'The Hunger Games');
INSERT INTO REVIEW (ReviewID, USerID, BookISBN, Rating, Note, Title) VALUES (5, 
'user1', '9780316015844', 2, 'Mid Book :(', 'Twilight');
INSERT INTO REVIEW (ReviewID, USerID, BookISBN, Rating, Note, Title) VALUES (6, 
'user3', '9781619635180', 3, 'Decent read but lacked charater devlopment', 'A Court Of Thorns And Roses');
INSERT INTO REVIEW (ReviewID, UserID, BookISBN, Rating, Note, Title) VALUES (7,
'user1', '9780735219090', 5, 'Absolutely loved it!', 'Where the Crawdads Sing');
INSERT INTO REVIEW (ReviewID, UserID, BookISBN, Rating, Note, Title) VALUES (8,
'user2', '9781982137335', 4, 'A compelling memoir!', 'Educated: A Memoir');
INSERT INTO REVIEW (ReviewID, UserID, BookISBN, Rating, Note, Title) VALUES (9,
'user3', '9780525562044', 5, 'inspiring and beautifully written.', 'Becoming');
INSERT INTO REVIEW (ReviewID, UserID, BookISBN, Rating, Note, Title) VALUES (10,
'user2', '9781984806758', 4, 'A thriller with a surprising twist.', 'The Silent Patient');
INSERT INTO REVIEW (ReviewID, UserID, BookISBN, Rating, Note, Title) VALUES (11,
'user1', '9780062871291', 5, 'captivating story.', 'Daisy Jones and The Six');
INSERT INTO REVIEW (ReviewID, UserID, BookISBN, Rating, Note, Title) VALUES (12,
'user1', '9781250787299', 4, 'Thrilling space adventure.', 'Project Hail Mary');
INSERT INTO REVIEW (ReviewID, UserID, BookISBN, Rating, Note, Title) VALUES (13,
'user2', '9781984818355', 5, 'An exploration of identity and famil.', 'The Vanishing Half');
INSERT INTO REVIEW (ReviewID, UserID, BookISBN, Rating, Note, Title) VALUES (14,
'user3', '9781250779171', 4, 'A compelling family saga.', 'Malibu Rising');
INSERT INTO REVIEW (ReviewID, UserID, BookISBN, Rating, Note, Title) VALUES (15,
'user3', '9780593135204', 5, 'A fantasy with a unique and enchanting story.', 'The Invisible Life of Addie LaRue');
INSERT INTO REVIEW (ReviewID, UserID, BookISBN, Rating, Note, Title) VALUES (16,
'user1', '9780316382716', 4, 'captivating and well-executed.', 'Circe');


-- Modify data for the READINGLIST table
INSERT INTO READINGLIST (Title, DateAdded, ReadingLID, Status, UserID) VALUES (
'Percy Jackson', '2023-01-01', 1, 'Not Started', 'user1');
INSERT INTO READINGLIST (Title, DateAdded, ReadingLID, Status, UserID) VALUES (
'The Book Theif', '2023-02-15', 2, 'In Progress', 'user2');
INSERT INTO READINGLIST (Title, DateAdded, ReadingLID, Status, UserID) VALUES (
'The Hunger Games', '2023-03-30', 3, 'Completed', 'user3');
INSERT INTO READINGLIST (Title, DateAdded, ReadingLID, Status, UserID) VALUES 
('The Seven Husbands of Evelyn Hugo', '2023-01-01', 4, 'Not Started', 'user1');
INSERT INTO READINGLIST (Title, DateAdded, ReadingLID, Status, UserID) VALUES 
('Fourth Wing', '2023-02-15', 5, 'In Progress', 'user2');
INSERT INTO READINGLIST (Title, DateAdded, ReadingLID, Status, UserID) VALUES
('Song of Achilles', '2023-03-30', 6, 'Completed', 'user3');



-- Display contents of the BOOK table
SELECT * FROM BOOK;

-- Display contents of the USERTABLE table
SELECT * FROM USERTABLE;

-- Display contents of the REVIEW table
SELECT * FROM REVIEW;

-- Display contents of the READINGLIST table
SELECT * FROM READINGLIST;